if (GAME_LOCALE or GetLocale()) ~= "frFR" then return end

local L = BuffOverlay.L

--@localization(locale="frFR", format="lua_additive_table", handle-subnamespaces="none")@
