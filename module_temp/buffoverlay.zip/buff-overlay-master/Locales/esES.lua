if (GAME_LOCALE or GetLocale()) ~= "esES" then return end

local L = BuffOverlay.L

--@localization(locale="esES", format="lua_additive_table", handle-subnamespaces="none")@
