if (GAME_LOCALE or GetLocale()) ~= "itIT" then return end

local L = BuffOverlay.L

--@localization(locale="itIT", format="lua_additive_table", handle-subnamespaces="none")@
