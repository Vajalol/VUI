if (GAME_LOCALE or GetLocale()) ~= "deDE" then return end

local L = BuffOverlay.L

--@localization(locale="deDE", format="lua_additive_table", handle-subnamespaces="none")@
