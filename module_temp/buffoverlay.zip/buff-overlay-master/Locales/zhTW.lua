if (GAME_LOCALE or GetLocale()) ~= "zhTW" then return end

local L = BuffOverlay.L

--@localization(locale="zhTW", format="lua_additive_table", handle-subnamespaces="none")@
