if (GAME_LOCALE or GetLocale()) ~= "zhCN" then return end

local L = BuffOverlay.L

--@localization(locale="zhCN", format="lua_additive_table", handle-subnamespaces="none")@
