if (GAME_LOCALE or GetLocale()) ~= "ptBR" then return end

local L = BuffOverlay.L

--@localization(locale="ptBR", format="lua_additive_table", handle-subnamespaces="none")@
