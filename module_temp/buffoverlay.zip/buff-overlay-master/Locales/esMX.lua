if (GAME_LOCALE or GetLocale()) ~= "esMX" then return end

local L = BuffOverlay.L

--@localization(locale="esMX", format="lua_additive_table", handle-subnamespaces="none")@
