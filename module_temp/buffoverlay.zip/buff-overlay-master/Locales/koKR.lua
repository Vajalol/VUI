if (GAME_LOCALE or GetLocale()) ~= "koKR" then return end

local L = BuffOverlay.L

--@localization(locale="koKR", format="lua_additive_table", handle-subnamespaces="none")@
