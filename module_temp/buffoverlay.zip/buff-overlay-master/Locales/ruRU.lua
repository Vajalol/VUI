if (GAME_LOCALE or GetLocale()) ~= "ruRU" then return end

local L = BuffOverlay.L

--@localization(locale="ruRU", format="lua_additive_table", handle-subnamespaces="none")@
