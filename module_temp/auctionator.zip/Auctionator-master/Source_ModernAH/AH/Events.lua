Auctionator.AH.Events.CommoditySearchResultsReady = "ah_commodity_results_ready"
Auctionator.AH.Events.ItemSearchResultsReady = "ah_item_results_ready"
