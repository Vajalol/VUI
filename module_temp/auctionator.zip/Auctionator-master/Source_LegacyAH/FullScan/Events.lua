Auctionator.FullScan.Events = {
  ScanStart = "get_all_scan_start",
  ScanProgress = "get_all_scan_progress",
  ScanComplete = "get_all_scan_complete",
  ScanFailed = "get_all_scan_failed",
}
