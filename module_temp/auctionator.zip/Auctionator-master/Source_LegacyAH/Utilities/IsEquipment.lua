function Auctionator.Utilities.IsEquipment(classID)
  return classID == Enum.ItemClass.Weapon or classID == Enum.ItemClass.Armor
end
