Auctionator.Cancelling.Events = {
  RequestCancel = "request_auction_cancellation",
  RequestCancelUndercut = "request_cancel_undercut_macro",
  CancelConfirmed = "cancel_confirmed",
  UndercutStatus = "undercut_status",
  UndercutScanStart = "undercut_scan_start",
  TotalUpdated = "cancelling_view_total_updated",
}
