Auctionator.AH.Events = {
  Ready = "AH_READY",
  ThrottleUpdate = "ah_throttle_update",
}
