AUCTIONATOR_LOCALES.deDE = function()
  local L = {}

  --@localization(locale="deDE", format="lua_additive_table")@

  return L
end
