AUCTIONATOR_LOCALES.zhCN = function()
  local L = {}

  --@localization(locale="zhCN", format="lua_additive_table")@

  return L
end
