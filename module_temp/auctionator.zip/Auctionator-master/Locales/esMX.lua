AUCTIONATOR_LOCALES.esMX = function()
  local L = {}

  --@localization(locale="esMX", format="lua_additive_table")@

  return L
end

