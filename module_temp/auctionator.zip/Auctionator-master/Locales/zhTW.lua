AUCTIONATOR_LOCALES.zhTW = function()
  local L = {}

  --@localization(locale="zhTW", format="lua_additive_table")@

  return L
end
