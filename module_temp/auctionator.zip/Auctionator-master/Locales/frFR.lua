AUCTIONATOR_LOCALES.frFR = function()
  local L = {}

  --@localization(locale="frFR", format="lua_additive_table")@

  return L
end
