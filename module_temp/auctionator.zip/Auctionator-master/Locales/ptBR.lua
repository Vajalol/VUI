AUCTIONATOR_LOCALES.ptBR = function()
  local L = {}

  --@localization(locale="ptBR", format="lua_additive_table")@

  return L
end

