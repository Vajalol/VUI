AUCTIONATOR_LOCALES.esES = function()
  local L = {}

  --@localization(locale="esES", format="lua_additive_table")@

  return L
end
