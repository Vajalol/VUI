AUCTIONATOR_LOCALES.koKR = function()
  local L = {}

  --@localization(locale="koKR", format="lua_additive_table")@

  return L
end
