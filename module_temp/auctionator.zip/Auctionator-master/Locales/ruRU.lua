AUCTIONATOR_LOCALES.ruRU = function()
  local L = {}

  --@localization(locale="ruRU", format="lua_additive_table")@

  return L
end
