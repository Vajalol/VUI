AUCTIONATOR_LOCALES.itIT = function()
  local L = {}

  --@localization(locale="itIT", format="lua_additive_table")@

  return L
end
