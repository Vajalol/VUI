## v0.32.5

* Locale update

## v0.32.3

* Locale update

## v0.32.2

* Update to schedule

## v0.32.1

* Bug fix

## v0.32.0

* Update for Schedule

## v0.31.11

* Some locale updates

## v0.31.10

* ToC bump

## v0.31.9

* ToC bump

## v0.31.8

* Update libs

## v0.31.7

* Update for schedule

## v0.31.6

* Update for schedule

## v0.31.5

* Add option to use MDT on tooltips, via CruelDrool

## v0.31.4

* Bug fixes

## v0.31.3

* Fixes for TWW

## v0.31.2

* Update for 11.0.2

## v0.31.1

* Update for deDE locale
* Bug fixes

## v0.31.0

* Initial TWW support

## v0.30.12

* Update to itIT localization

## v0.30.11

* ToC bump

## v0.30.10

* ToC bump

## v0.30.9

* Localization update

## v0.30.8

* Localization update

## v0.30.7

* Updated libs

## v0.30.6

* ToC bump

## v0.30.5

* Schedule update

## v0.30.4

* Update for 10.2

## v0.30.3

* ToC bump

## v0.30.2

* Updated libs

## v0.30.1

* Updated locales

## v0.30.0

* Added complete schedule back

## v0.29.3

* Bug fixes

## v0.29.2

* Update and bug fixes for schedule

## v0.29.1

* Update schedule for season 2, via nanjuekaien1

## v0.29.0

* Support for using KalielsTracker, can use if having taint issues

## V0.28.4

* Locale update
* ToC bump

## v0.28.3

* ToC bump

## v0.28.1

* Add time limit to dungeon icon tooltip, via sehra

## v0.28.0

* Adjusted display for party keystones for longer dungeon names, via willoucom

## v0.27.0

* Added Shadowlands season 1 schedule
* Bug fixes

## v0.26.6

* Bug fix for auto slotting keystones

## v0.26.5

* Lib updates

## v0.26.4

* Bug fixes

## v0.26.3

* Bug fixes

## v0.26.2

* Bug fix for patch (via IceQ1337)

## v0.26.1

* Bug fix for auto gossip (via Numynum)

## v0.26.0

* Bug fix for 10.0 (via sehra)

## v0.25.4

* ToC bump

## v0.25.3

* Small bug fixes

## v0.25.2

* ToC bump

## v0.25.1

* Bug fixes

## v0.25.0

* Update to new affix schedule (via marthammor)
* Restore CoS rumor announce (via marthammor)

## v0.24.1

* Added option to disable keystone schedule and party keystones in Mythic Keystone window

## v0.24.0

* Trimmed Tazavesh keystone names in schedule (thanks siweia)

## v0.23.1

* Bug fixes

## v0.23.0

* Bug fixes
* ToC bump for 9.1.5

## v0.22.1

* Bug fixes

## v0.22.0

* Updated schedule for Shadowlands Season 2

## v0.21.0

* Added French localization (thanks willoucom)

## v0.20.2

* Bug fixes

## v0.20.1

* Bug fixes

## v0.20.0

* Added localization updates

## v0.19.8b

* Schedule update

## v0.19.7

* ToC bump

## v0.19.6

* Updated schedule for Shadowlands
* Show progress remaining until next prideful activation

## v0.19.4

* Fixed bug with Kyrian Steward

## v0.19.3

* Bug fixes

## v0.19.2

* Bug fixes

## v0.19.1

* Initial support for 9.0
* ToC bump

## v0.18.4

* ToC bump
* Small bug fix to not use deprecated function

## v0.18.3

* Update to affix schedule

## v0.18.2

* Small bug fix

## v0.18.1

* Added updated Keystone schedule

## v0.18.0

* Added message stating new keystone schedule is unknown, it will be update once it is.

## v0.17.3

* Bug fixes

## v0.17.2b

* Small bugfix for Reaping tracker

## v0.17.1

* Small bugfix

## v0.17.0

* Added counter until next Reaping spawn above enemy forces meter

## v0.16.1

* ToC Bump

## v0.16.0

* Update for 8.1

## v0.15.7

* Bug fixes

## v0.15.6

* Bug fixes

## v0.15.5

* Bug fixes

## v0.15.4

* Small bug fix

## v0.15.3

* Localizations update

## v0.15.2

* Bug fixes

## v0.15.1

* Added option to announce your newly acquired Keystone to your party. Disabled by default.
* Localization updates

## v0.15.0

* Added showing which Keystones each party member has, if they are running AngryKeystones. They are displayed below the Keystone schedule in the Mythic Dungeon pane.

## v0.14.0

* Readded affix schedule to Mythic dungeon pane

## v0.13.7

* Only auto select gossip entries during active Keystone dungeon

## v0.13.6

* Display number of deaths per player on Death Tracker tooltip

## v0.13.5

* Fixes for displaying mob progress amount on tooltips

## v0.13.4

* Options panel bug fixes

## v0.13.3

* More bug fixes

## v0.13.2

* Small bug fix

## v0.13.1

* ToC bump

## v0.13.0

* Disable Schedule feature for now due to 8.0 changes, will come back in the future

## v0.12.12

* Update to affix schedule

## v0.12.11

* Update to affix schedule

## v0.12.10

* Minor bug fixes

## v0.12.9

* Update for 7.3.5

## v0.12.8

* Update for 7.3.2

## v0.12.7

* Update for 7.3

## v0.12.6

* German localization update

## v0.12.5

* Reenabled and updated the schedule feature

## v0.12.4

* When death tracker is enabled hide the newly added default one.

## v0.12.3

* Small bug fix.

## v0.12.2

* Updated Locales.

## v0.12.1

* Removed options continue showing tracker at end of Keystone runs and hide quest and achievements during keystones, due to taint issues since the LFG change.

## v0.12.0

* Added ability to automatically slot keystone into keystone activation window.

## v0.11.2

* Updated Locales.

## v0.11.1

* Bugfix for 7.2.0.

## v0.11.0

* Initial update for 7.2.0. Schedule is disabled for now, since unsure of new schedule.

## v0.10.1

* Small bug fix.

## v0.10.0

* Added option to show popup to reset instances after leaving a Mythic Keystone dungeon.

## v0.9.5

* Update for 7.1.5.

## v0.9.4

* Locale updates.

## v0.9.3

* Displays a message when schedule isn't displayed due to not having a level 7+ Keystone, instead of just hiding the frame.
* If "DropDownMenu" library is present it will be used over builtin dropdown menus, so to not cause taint.

## v0.9.2

* Updated koKR locale, including support for outputting rumors in Court of Stars.

## v0.9.1

* Updated zhCN locale, including support for outputting rumors in Court of Stars.

## v0.9.0

* Added ability to hide Talking Head dialog during Mythic Keystone dungeons. Can be disabled in the settings.
* Added new progress format option for showing remaining progress.

## v0.8.1

* Updated zhCN and zhTW locales.
* When hiding quest and achievement trackers, they are shown when in a completed Mythic Keystone dungeon.

## v0.8.0

* Added an option to hide quest and achievement trackers during Mythic Keyston dungeons. Disabled by default and required Reload UI to take effect.

## v0.7.1

* Updated koKR localization.

## v0.7.0

* Added a Schedule section to the Mythic Dungeon pane show the order of upcoming affixes. Will only display if you currently have a level 7+ Keystone in your inventory.
* Added an option to continue showing objective tracker after the completion of a Mythic Keystone dungeon. Disabled by default.

## v0.6.9

* Small bug fix for progress tooltips

## v0.6.8

* Small bug fixes

## v0.6.7

* Small bug fixes

## v0.6.6

* Fix for auto gossip for NPCs with static popups

## v0.6.5

* Added split timings message to completion message
* Fix for auto gossip on zone out NPC in Vault of the Wardens
* Updated locales

## v0.6.4

* Minor bug fix for death tracker

## v0.6.3

* Death tracker no longer counts Feign Death or Surrender to Madness deaths

## v0.6.2

* ToC update for 7.1
* Updated zhCN, zhTW locales

## v0.6.1

* Updated deDE localization

## v0.6.0

* Added death tracker to timer frame. Shows total number of deaths that run, with tooltip showing breakdown per player. Can be disabled in options.
* Reduced size of affix icons in timer frame, to make room for other information. Can be disabled in options.

## v0.5.2

* Fixed bug with progress tooltips in certain locales
* Reaves is now excluded from auto gossip

## v0.5.1

* Added option to adjust display for split timings on objective tracker

## v0.5.0

* Added option to show text output at completion of runs showing final run time
* Added option to display of how long each objective took to complete in objective tracker

## v0.4.0

* Added new feature to output to chat clues from Chatty Rumormongers during the Court of Stars event. Disabled by default, and currently only available in English locales
* When you go pass the time limit, the counter will now start counting up for how far past you are
* Added option to show 2 bonus chest timer while 3 bonus chest timer is still active
* Added zhCN and zhTW locales

## v0.3.0

* Added new feature to auto select gossip entries (ex: Odyn) during Keystone dungeons

## v0.2.1

* Added koKR locale

## v0.2.0

* Added ruRU, deDE, and esES locales

## v0.1.3

* Adds progress tooltips at end of tooltips when translation for current language is missing

## v0.1.2

* Bug fix for Keystone links from other languages

## v0.1.1

* Bug fix for progress tooltips

## v0.1

* Initial release
