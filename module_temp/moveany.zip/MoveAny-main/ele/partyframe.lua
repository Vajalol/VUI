local _, MoveAny = ...

function MoveAny:InitPartyFrame()
end
--PartyFrame:SetSize(120, 244)