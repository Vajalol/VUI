# SUI

## [10.2.20](https://github.com/Syiana/SUI/tree/10.2.20) (2024-05-28)
[Full Changelog](https://github.com/Syiana/SUI/compare/10.2.19...10.2.20) [Previous Releases](https://github.com/Syiana/SUI/releases)

- Updated SUI version  
- Removed MicroMenu Resizing  
