# Generate documentation

The documentation is written inside several markdown files and in the source code of .lua

Steps:

1. ensure "ldoc" has been installed. Install by "luarocks install ldoc"
2. in this folder ("docs" folder in LibDeflate source tree), run "ldoc ."
