# LibNPCInfo

## [v1.005](https://github.com/fang2hou/LibNPCInfo/tree/v1.005) (2024-07-28)
[Full Changelog](https://github.com/fang2hou/LibNPCInfo/compare/v1.004...v1.005) [Previous Releases](https://github.com/fang2hou/LibNPCInfo/releases)

- toc: bump version  
