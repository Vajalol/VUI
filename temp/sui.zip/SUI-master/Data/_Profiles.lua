local Profiles = SUI:NewModule('Data.Profiles');

Profiles.data = {
    { value = 'Default', text = 'Default' },
}