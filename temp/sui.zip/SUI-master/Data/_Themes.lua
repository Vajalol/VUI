local Themes = SUI:NewModule('Data.Themes');

Themes.data = {
  { value = 'Blizzard', text = 'Blizzard' },
  { value = 'Dark', text = 'Dark' },
  { value = 'Class', text = 'Class' },
  { value = 'Custom', text = 'Custom' }
}