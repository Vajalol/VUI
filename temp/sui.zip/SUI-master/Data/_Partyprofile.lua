local Partyprofile = SUI:NewModule('Data.Partyprofile');

Partyprofile.data = {
    { value = 'profile1', text = 'Profile 1' },
    { value = 'profile2', text = 'Profile 2' },
}