---
name: Suggestion
about: Missing something? Feel free to suggest
title: ""
labels: 'Suggestion'
assignees: 'muleyo'

---

**Description**

**Game version**

**Screenshots (if applicable)**
