# Sound Files

The following sound files need to be sourced from their original addons:

## Required Files
- `harrier.ogg` - Used by the Position of Power feature in the Tools module
  - Source: Original WoW sound file for Harrier's Cry ability

These audio files should be properly licensed and sourced from the original addon repositories or extracted from WoW game files, ensuring that all copyright and licensing requirements are met.