if not SlashCmdList.RELOADUI then
	SLASH_RELOADUI1 = "/rl"
	SlashCmdList["RELOADUI"] = ReloadUI
end
